# SEO metadata sample

各 テンプレート の `<head>` セクション で 使う SEO メタ の 参考 値。

## title タグ (60 文字 以内 推奨)

```
<title>{{TITLE}} — {{SITE_NAME}}</title>
```

例: `Python データ 分析 書籍 5 選 (2026) — MyBlog`

## description メタ (120-160 文字 推奨)

```
<meta name="description" content="{{DESCRIPTION}}">
```

例: `2026 年 に データ 分析 実務 で 使える Python 書籍 を 5 冊 紹介。 章 単位 で 用途 を 明示 し、楽天ブックス で 手 に 入る 版 に 誘導。`

## Open Graph (SNS シェア 対応)

```html
<meta property="og:type" content="article">
<meta property="og:url" content="https://your-blog.com/entry/xxx.html">
<meta property="og:title" content="{{TITLE}}">
<meta property="og:description" content="{{DESCRIPTION}}">
<meta property="og:image" content="https://your-blog.com/img/xxx-ogp.png">
<meta property="og:locale" content="ja_JP">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{TITLE}}">
<meta name="twitter:description" content="{{DESCRIPTION}}">
<meta name="twitter:image" content="https://your-blog.com/img/xxx-ogp.png">
```

## JSON-LD (schema.org Article)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "{{TITLE}}",
  "description": "{{DESCRIPTION}}",
  "inLanguage": "ja",
  "author": { "@type": "Person", "name": "{{AUTHOR}}" },
  "publisher": { "@type": "Organization", "name": "{{SITE_NAME}}", "url": "https://your-blog.com/" },
  "datePublished": "{{PUBLISH_DATE}}",
  "mainEntityOfPage": "https://your-blog.com/entry/xxx.html"
}
</script>
```

## canonical URL

```html
<link rel="canonical" href="https://your-blog.com/entry/xxx.html">
```

複数 の ドメイン (note / WordPress / 自社 サイト) に 転載 する 場合 は canonical で 原本 を 指す。

## disclosure (アフィリエイト 開示)

記事 冒頭 (h1 直後) に:

```html
<p class="disclosure" style="font-size:.85rem;color:#666;margin:8px 0 24px;border-left:3px solid #d5d5d5;padding-left:12px;">
本 記事 に は 楽天アフィリエイト リンク を 含み ます。 リンク先 で の 購入 に より 紹介料 が 発生 する 場合 が あります。 記事 内容 と 紹介 商品 の 選定 は 独立 して 行って います。
</p>
```

## robots

```html
<meta name="robots" content="index,follow,max-image-preview:large">
```

低 品質 な 転載 が 疑われ そう な ページ (ドラフト) は `noindex,follow`。
