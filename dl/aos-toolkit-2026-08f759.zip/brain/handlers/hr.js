'use strict';
// HR handler - AI employee roster + skill / XP tracking + rotation policy.
// The people gate: any hiring / firing of a real human requires human decision.

const EMPLOYEE_ID = 'hr';

async function run(db, ctx = {}) {
  const roster = db.prepare(
    `SELECT employee_id, last_run_at, last_status, run_count
       FROM employee_state ORDER BY employee_id`
  ).all();

  const idle = roster.filter(r => !r.last_run_at || (Date.now() - Date.parse(r.last_run_at) > 6 * 3600 * 1000));

  for (const r of idle) {
    db.prepare(
      `INSERT INTO detection (employee_id, severity, category, subject, status, detected_at)
       VALUES (?, 'medium', 'hr', ?, 'open', datetime('now'))`
    ).run(EMPLOYEE_ID, `AI employee ${r.employee_id} idle > 6h`);
  }

  db.prepare(
    `INSERT INTO brain_task (employee_id, kind, title, body_md, status, created_at)
     VALUES (?, 'report', ?, ?, 'done', datetime('now'))`
  ).run(
    EMPLOYEE_ID,
    `HR roster ${new Date().toISOString().slice(0,10)}`,
    `Total AI employees: ${roster.length}, idle > 6h: ${idle.length}`
  );

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, total: roster.length, idle: idle.length };
}

module.exports = { run, EMPLOYEE_ID };
