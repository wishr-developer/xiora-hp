'use strict';
// Security handler - policy audit + secret scan + halt-condition monitor.
// Escalates on the delete gate (irreversible operations).

const EMPLOYEE_ID = 'security';

const SECRET_PATTERNS = [
  /sk_live_[A-Za-z0-9]{16,}/,
  /sk_test_[A-Za-z0-9]{16,}/,
  /rk_live_[A-Za-z0-9]{16,}/,
  /AKIA[0-9A-Z]{16}/,       // AWS access key
  /AIza[0-9A-Za-z_-]{35}/,  // Google API key
];

async function scanRow(text) {
  if (!text) return [];
  const hits = [];
  for (const p of SECRET_PATTERNS) {
    if (p.test(text)) hits.push(p.source);
  }
  return hits;
}

async function run(db, ctx = {}) {
  // Sample last 100 task bodies and scan for accidentally embedded secrets.
  const rows = db.prepare(
    `SELECT id, body_md FROM brain_task
      WHERE created_at > datetime('now','-1 day')
      ORDER BY created_at DESC LIMIT 100`
  ).all();

  let leaks = 0;
  for (const r of rows) {
    const hits = await scanRow(r.body_md);
    if (hits.length) {
      db.prepare(
        `INSERT INTO detection (employee_id, severity, category, subject, status, detected_at)
         VALUES (?, 'critical', 'security', ?, 'open', datetime('now'))`
      ).run(EMPLOYEE_ID, `Secret pattern in brain_task id=${r.id}: ${hits.join(', ')}`);
      leaks += 1;
    }
  }

  db.prepare(
    `INSERT INTO brain_task (employee_id, kind, title, body_md, status, created_at)
     VALUES (?, 'report', ?, ?, 'done', datetime('now'))`
  ).run(
    EMPLOYEE_ID,
    `Security sweep ${new Date().toISOString().slice(0,16)}`,
    `Scanned ${rows.length} rows, ${leaks} suspected leaks.`
  );

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), ?, 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = ?, run_count = run_count + 1`
  ).run(EMPLOYEE_ID, leaks ? 'warn' : 'ok', leaks ? 'warn' : 'ok');

  return { ok: leaks === 0, employee: EMPLOYEE_ID, leaks };
}

module.exports = { run, EMPLOYEE_ID };
