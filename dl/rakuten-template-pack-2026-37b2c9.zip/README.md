# Rakuten Article Template Pack 2026

副業 楽天アフィリエイター 向け の 「1 記事 30 分 で 公開できる」 テンプレート 5 セット。

## 収録内容

- `template-01-ai-dev.html` (AI 開発書籍 5 選 テンプレ)
- `template-02-python-data.html` (Python / データ分析 書籍 5 選 テンプレ)
- `template-03-startup-marketing.html` (スタートアップ マーケ 書籍 5 選 テンプレ)
- `template-04-solo-founder.html` (単独創業 書籍 5 選 テンプレ)
- `template-05-smb-dx.html` (中小企業 DX 書籍 5 選 テンプレ)
- `RAFCID_GUIDE.md` (rafcid 取得 + hgc URL 生成 手順)
- `SEO_METADATA.md` (title / description / JSON-LD の 使い方)

## 想定 読者

- 楽天アフィリエイト を これから 始める 個人
- 書評 / まとめ 系 の ブログ を 育てたい 副業志望者
- SEO を 意識 した 一次コンテンツ を 短時間 で 量産 したい ライター

## 使い方 (1 記事 30 分)

1. `RAFCID_GUIDE.md` の 手順 で 楽天アフィリエイト に 登録 (10 分)
2. rafcid (会員 ID) を コピー
3. どれか 1 つ の テンプレート を 開く
4. `{{...}}` の placeholder を 置き換え (15 分)
   - `{{TITLE}}` = 記事 の H1
   - `{{DISCLOSURE}}` = アフィリエイト 開示 文
   - `{{BOOK_NAME_1}}` ... `{{BOOK_NAME_5}}` = 5 冊 の 書籍 名
   - `{{RAKUTEN_URL_1}}` ... `{{RAKUTEN_URL_5}}` = 楽天ブックス 検索 URL (rafcid 込み)
5. 自社 の ブログ / note / WordPress に 貼り付け (5 分)

## 免責

- 本 pack は 情報提供 目的。 記事 の 収益 は 集客 / 選書 / 表現 に よって 変動 します。
- 楽天 の 規約 変更 (rafcid の 廃止 や 手数料 改定) に は 個別 対応 が 必要 です。
- お問い合わせ: info@xiora-official.com

(c) 2026 Xiora. Personal + commercial use allowed. Redistribution as-is prohibited.
