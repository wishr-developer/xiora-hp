# Claude API + Ollama Integration Runbook

Anthropic Claude API と ローカル Ollama を 併用 して 対話 layer の コスト と 応答速度 を 最適化 する パターン。

## 全体像

```
User query -> router
   query length <= 300 tokens AND type in (classify, extract, summarize)  -> Ollama (local, free)
   query length > 300 tokens OR type in (draft, reason, code)              -> Claude API (paid)
```

24/7 loop の 大半 は 分類 と 要約 で、これは Ollama で 十分 な 品質 が 出る。 深い 推論 と 長文 生成 だけ Claude API に 送る こと で、月額 の LLM 費用 を 数千円 レンジ に 押さえられる。

## 1. Anthropic API

```javascript
// lib/claude.js
async function claudeMessage(prompt, opts = {}) {
  const key = process.env.ANTHROPIC_API_KEY;
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': key,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: opts.model || 'claude-3-5-sonnet-latest',
      max_tokens: opts.max_tokens || 1024,
      messages: [{ role: 'user', content: prompt }],
    }),
  });
  if (!r.ok) throw new Error(`claude http ${r.status}`);
  const j = await r.json();
  return j.content[0].text;
}

module.exports = { claudeMessage };
```

## 2. Ollama local

```bash
# Install (macOS)
brew install ollama
brew services start ollama

# Pull a fast local model
ollama pull qwen2.5:7b

# Verify
curl -sS http://localhost:11434/api/tags | jq '.models[].name'
```

```javascript
// lib/ollama.js
async function ollamaGenerate(prompt, opts = {}) {
  const host = process.env.OLLAMA_HOST || 'http://localhost:11434';
  const model = opts.model || 'qwen2.5:7b';
  const r = await fetch(`${host}/api/generate`, {
    method: 'POST',
    body: JSON.stringify({ model, prompt, stream: false }),
  });
  const j = await r.json();
  return j.response;
}

module.exports = { ollamaGenerate };
```

## 3. Router (cost governor)

```javascript
// lib/llm-router.js
const { claudeMessage } = require('./claude');
const { ollamaGenerate } = require('./ollama');

async function route(prompt, opts = {}) {
  const isSimple = (opts.taskType === 'classify' || opts.taskType === 'extract' || opts.taskType === 'summarize');
  const isShort = prompt.length < 1200; // ~300 tokens
  if (isSimple && isShort) return ollamaGenerate(prompt, opts);
  return claudeMessage(prompt, opts);
}

module.exports = { route };
```

## 4. Budget guard

```javascript
// lib/budget.js
async function checkBudget(db, dailyLimitJpy) {
  const spent = db.prepare(
    `SELECT COALESCE(SUM(cost_jpy),0) AS total
       FROM llm_call_log WHERE called_at > datetime('now','-1 day')`
  ).get().total;
  if (spent >= dailyLimitJpy) throw new Error(`llm daily budget exceeded: ${spent} >= ${dailyLimitJpy}`);
  return { spent, remaining: dailyLimitJpy - spent };
}

module.exports = { checkBudget };
```

## 5. Prompt caching (Anthropic)

Long, stable system prompts (multi-KB context) can be cached to cut cost 80-90%:

```javascript
const body = {
  model: 'claude-3-5-sonnet-latest',
  max_tokens: 1024,
  system: [
    { type: 'text', text: LARGE_STABLE_CONTEXT, cache_control: { type: 'ephemeral' } },
  ],
  messages: [{ role: 'user', content: userQuery }],
};
```

Cache TTL is roughly 5 minutes; ensure the cached prefix is exactly identical between calls to hit the cache.

## 6. Observability

Log every LLM call to `llm_call_log(model, tokens_in, tokens_out, cost_jpy, called_at, purpose)`. This lets Finance handler roll up daily cost, and lets Security handler catch anomalies (prompt injection attempts, unusual token counts).
