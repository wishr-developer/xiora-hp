'use strict';
// Research handler - background scans, competitor watchlist, prior-art audit.

const EMPLOYEE_ID = 'research';

async function run(db, ctx = {}) {
  const tasks = db.prepare(
    `SELECT id, title FROM brain_task
      WHERE employee_id = ? AND kind = 'research' AND status = 'pending'
      ORDER BY created_at ASC LIMIT 10`
  ).all(EMPLOYEE_ID);

  let processed = 0;
  for (const t of tasks) {
    const notes = [
      `# Research notes: ${t.title}`,
      `- Sources checked: (stub) list the URLs / repositories / papers.`,
      `- Key finding 1: (stub) what changes the decision.`,
      `- Key finding 2: (stub) what confirms an existing assumption.`,
      `- Next action: (stub) hand off to writer / developer / sales.`,
    ].join('\n');

    db.prepare(`UPDATE brain_task SET body_md = ?, status = 'done' WHERE id = ?`).run(notes, t.id);
    processed += 1;
  }

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, processed };
}

module.exports = { run, EMPLOYEE_ID };
