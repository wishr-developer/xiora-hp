'use strict';
// Manager handler - task assignment + owner rebalancing.
// Picks up orphan brain_task rows and assigns them to the correct AI employee.

const EMPLOYEE_ID = 'manager';

const DEFAULT_ROUTING = {
  code:      'developer',
  research:  'research',
  qa:        'qa',
  content:   'writer',
  billing:   'finance',
  campaign:  'marketing',
  outbound:  'sales',
  people:    'hr',
  ticket:    'support',
  audit:     'security',
};

async function run(db, ctx = {}) {
  const routing = Object.assign({}, DEFAULT_ROUTING, ctx.routing || {});

  const orphan = db.prepare(
    `SELECT id, kind, title FROM brain_task
      WHERE (employee_id IS NULL OR employee_id = '')
        AND status IN ('new','pending')
      ORDER BY created_at ASC LIMIT 50`
  ).all();

  let assigned = 0;
  const upd = db.prepare(`UPDATE brain_task SET employee_id = ?, status = 'pending' WHERE id = ?`);
  for (const row of orphan) {
    const target = routing[row.kind] || 'developer';
    upd.run(target, row.id);
    assigned += 1;
  }

  db.prepare(
    `INSERT INTO brain_task (employee_id, kind, title, body_md, status, created_at)
     VALUES (?, 'report', ?, ?, 'done', datetime('now'))`
  ).run(
    EMPLOYEE_ID,
    `Manager tick ${new Date().toISOString().slice(0,16)}`,
    `Assigned ${assigned} orphan tasks (out of ${orphan.length} candidates).`
  );

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, assigned };
}

module.exports = { run, EMPLOYEE_ID };
