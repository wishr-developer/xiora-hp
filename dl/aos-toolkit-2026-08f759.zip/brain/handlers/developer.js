'use strict';
// Developer handler - code tasks (draft PR / patch / test scaffolding).
// Reference implementation: picks up code kind tasks and marks them as
// awaiting-human-review after drafting a plan.

const EMPLOYEE_ID = 'developer';

async function run(db, ctx = {}) {
  const tasks = db.prepare(
    `SELECT id, title, body_md FROM brain_task
      WHERE employee_id = ? AND kind = 'code' AND status = 'pending'
      ORDER BY created_at ASC LIMIT 10`
  ).all(EMPLOYEE_ID);

  let drafted = 0;
  for (const t of tasks) {
    const plan = [
      `# Draft plan for: ${t.title}`,
      ``,
      `## Change scope`,
      `- (auto-drafted stub) List the files that need to change.`,
      ``,
      `## Tests`,
      `- (auto-drafted stub) Enumerate the assertions that must pass.`,
      ``,
      `## Rollout`,
      `- (auto-drafted stub) Describe how the change ships to production.`,
      ``,
      `## Human review required`,
      `- This draft was produced by the developer handler and requires human review before merge.`,
    ].join('\n');

    db.prepare(
      `UPDATE brain_task SET body_md = ?, status = 'review' WHERE id = ?`
    ).run((t.body_md || '') + '\n\n---\n\n' + plan, t.id);
    drafted += 1;
  }

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, drafted };
}

module.exports = { run, EMPLOYEE_ID };
