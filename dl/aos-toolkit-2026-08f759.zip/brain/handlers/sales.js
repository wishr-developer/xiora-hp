'use strict';
// Sales handler - outbound draft + pipeline advancement + follow-up scheduler.
// External send always requires human approval (contract / permission gate).

const EMPLOYEE_ID = 'sales';

async function run(db, ctx = {}) {
  const tasks = db.prepare(
    `SELECT id, title, body_md FROM brain_task
      WHERE employee_id = ? AND kind = 'outbound' AND status = 'pending'
      ORDER BY created_at ASC LIMIT 10`
  ).all(EMPLOYEE_ID);

  let drafted = 0;
  for (const t of tasks) {
    const draft = [
      `# Outbound draft: ${t.title}`,
      ``,
      `Subject : (stub) tailored subject line.`,
      `Preview : (stub) one-line preview.`,
      ``,
      `Body    :`,
      `(stub) 3-paragraph draft with a clear ask + 1 CTA + 1 opt-out.`,
      ``,
      `## Human gate`,
      `External send requires an explicit human approval. This handler drafts only.`,
    ].join('\n');
    db.prepare(`UPDATE brain_task SET body_md = ?, status = 'review' WHERE id = ?`).run(draft, t.id);
    drafted += 1;
  }

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, drafted };
}

module.exports = { run, EMPLOYEE_ID };
