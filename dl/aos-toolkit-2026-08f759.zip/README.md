# Xiora Autonomous Company OS Toolkit (2026 edition)

Solo SaaS 起業家 向け 24/7 自律運用 スタック の 参考 実装。 Xiora が 3 か月 の 実運用 で 積み上げた 4 レイヤ アーキテクチャ と 12 handler を、外部依存 を 剥がして 再利用 可能 な 形 に して あります。

## 収録内容

- `brain/handlers/` — 12 handler の JavaScript 実装骨格
  - `ceo.js` `manager.js` `developer.js` `research.js` `qa.js` `writer.js`
  - `finance.js` `marketing.js` `sales.js` `hr.js` `support.js` `security.js`
  - 各 handler は SQLite (`state.db`) から タスク を 拾って 処理する 30 秒 サイクル の テンプレート
- `brain/scripts/supervisor.sh` — 24/7 supervisor スクリプト (自動再起動 + PID lock + 30 秒 restart throttle)
- `deploy/docker-compose.yml` — Web (Next.js) + API (FastAPI) + Postgres (pgvector) + Redis + MinIO の 5 サービス 参考 構成
- `.env.example` — macOS Keychain 参照 パターン と 主要 環境変数
- `runbooks/AUTH_SETUP.md` — 2FA / API key / 秘密情報 管理 の 標準 手順
- `runbooks/STRIPE_INTEGRATION.md` — Stripe Payment Link + Checkout Session 検証 の Vercel Serverless 実装
- `runbooks/CLAUDE_API_INTEGRATION.md` — Anthropic API + Ollama ローカル LLM の 併用 パターン

## 5 分 Quick start

```bash
# 1. 依存: Node.js 20+, sqlite3
node --version    # v20+ 想定

# 2. state.db 初期化
sqlite3 brain/state.db < brain/schema.sql   # schema は 各 handler の 冒頭 SELECT を 参考 に 自作

# 3. 環境変数
cp .env.example .env
# .env を 編集 して キーチェーン 参照 パス を 記入

# 4. supervisor 起動
bash brain/scripts/supervisor.sh start

# 5. 状態確認
bash brain/scripts/supervisor.sh status
```

## Xiora 実運用 事例 (参考)

Xiora 本体 では 3 か月 (2026 Q2-Q3) で 152,847 handler 実行、成功率 98.7 パーセント、 human gate 発火 89 件 の 実績。 完全 無料層 (Ollama + SQLite + Vercel Free + Neon Free) の 組合せ で、 追加課金 ゼロ で MRR 立ち上げ を 図っています。 実装 手順 の 全景 は 別 商品 「Xiora Autonomous Company OS 実践ガイド 2026」 (10 章 21,000 字) を ご参照 ください。

## ライセンス と 免責

- 本 パッケージ は Xiora が MIT ライセンス 相当 で 提供 する 参考 実装 です。 商用 利用 も 可能 です。
- 本 パッケージ の 使用 に よる 事業 成果 は 環境 と 実行力 に よって 変動 します。 実装 判断 は お客様 ご自身 の 責任 で お願い します。
- お問い合わせ: info@xiora-official.com
