'use strict';
// Writer handler - long-form content drafting (blog / SEO article / update note).
// Produces a draft body_md and marks the task ready for editorial review.

const EMPLOYEE_ID = 'writer';

const SECTIONS = [
  '## Lead paragraph',
  '## Problem',
  '## Approach',
  '## Result / evidence',
  '## Next step for the reader',
];

async function run(db, ctx = {}) {
  const tasks = db.prepare(
    `SELECT id, title, body_md FROM brain_task
      WHERE employee_id = ? AND kind = 'content' AND status = 'pending'
      ORDER BY created_at ASC LIMIT 10`
  ).all(EMPLOYEE_ID);

  let drafted = 0;
  for (const t of tasks) {
    const draft = [
      `# ${t.title}`,
      ``,
      ...SECTIONS.flatMap(s => [s, '- (auto-drafted stub) fill in with evidence.', '']),
      `---`,
      `Draft produced by writer handler. Awaiting editorial review.`,
    ].join('\n');
    db.prepare(`UPDATE brain_task SET body_md = ?, status = 'review' WHERE id = ?`).run(draft, t.id);
    drafted += 1;
  }

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, drafted };
}

module.exports = { run, EMPLOYEE_ID };
