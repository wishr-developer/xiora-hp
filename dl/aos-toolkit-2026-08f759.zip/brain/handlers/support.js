'use strict';
// Support handler - customer ticket triage + first-response drafting.
// External reply requires human approval before send.

const EMPLOYEE_ID = 'support';

async function run(db, ctx = {}) {
  const tickets = db.prepare(
    `SELECT id, title, body_md FROM brain_task
      WHERE employee_id = ? AND kind = 'ticket' AND status = 'pending'
      ORDER BY created_at ASC LIMIT 20`
  ).all(EMPLOYEE_ID);

  let drafted = 0;
  for (const t of tickets) {
    const draft = [
      `# Support draft: ${t.title}`,
      ``,
      `Suggested category: (stub) bug / question / refund / feature request.`,
      ``,
      `Draft reply:`,
      `Hi (customer),`,
      ``,
      `Thanks for reaching out. (stub) 2-3 sentence acknowledgement + next step.`,
      ``,
      `-- Support`,
      ``,
      `## Human gate`,
      `External send requires human approval. Draft only.`,
    ].join('\n');
    db.prepare(`UPDATE brain_task SET body_md = ?, status = 'review' WHERE id = ?`).run(draft, t.id);
    drafted += 1;
  }

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, drafted };
}

module.exports = { run, EMPLOYEE_ID };
