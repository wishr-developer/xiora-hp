# Auth Setup Runbook

外部 SaaS の 2FA / API key / 秘密情報 を 安全 に 集約 する 標準 手順。

## 目的

- 全 アカウント に 2FA を 強制 する
- API key を レポジトリ に 平文 で 置かない
- 秘密情報 は macOS Keychain または 1Password CLI で 集中管理

## 1. 全 アカウント 2FA 化 (30 分)

対象 (最小):
- GitHub / GitLab
- Cloud provider (AWS / GCP / Vercel / Cloudflare)
- Stripe (会社 owner + billing 権限)
- Google Workspace
- Anthropic / OpenAI / その他 LLM プロバイダ
- ドメインレジストラ

各 アカウント の Security 設定 で TOTP (Google Authenticator 等) を 有効化。 SMS 2FA は SIM swap リスク が あるため 避ける。 復旧 コード は 印刷 して オフライン 保管。

## 2. Vault (Keychain) セットアップ (10 分)

macOS の 場合:

```bash
# 秘密情報 の 登録
security add-generic-password -a "$USER" -s "myorg:anthropic:API_KEY" -w
# プロンプト で キー を 貼り付け (パスワードとして 保存)

# 参照
security find-generic-password -s "myorg:anthropic:API_KEY" -w
```

命名規則: `<org>:<service>:<KEY_NAME>` で 統一。

Linux / VPS の 場合 は 1Password CLI か HashiCorp Vault を 推奨。

## 3. アプリ 起動時 の 参照 パターン

```bash
# start.sh
export ANTHROPIC_API_KEY=$(security find-generic-password -s "myorg:anthropic:API_KEY" -w)
export STRIPE_SECRET_KEY=$(security find-generic-password -s "myorg:stripe:SECRET_KEY" -w)
node brain/runtime.js
```

`.env` ファイル に 平文 で 書か ない。 CI/CD は プロバイダ の Secret Store (GitHub Actions Secrets / Vercel Environment Variables 等) を 使用。

## 4. Restricted key の 徹底

- Stripe: verifier 用 は `Checkout Sessions Read` のみ の restricted key
- AWS: IAM policy で 最小権限
- GitHub: Personal access token (fine-grained) で repository と scope を 限定

漏洩 時 の 被害範囲 を 最小化 する 設計。

## 5. 定期 rotation

- 3 か月 ごと に 全 API key を rotate
- ローテーション 日程 を カレンダー に 固定 (第 1 月曜 等)
- 旧 key の 削除 は 新 key の 動作 確認 後
