'use strict';
// Marketing handler - campaign draft + attribution rollup + creative queue.

const EMPLOYEE_ID = 'marketing';

async function run(db, ctx = {}) {
  const tasks = db.prepare(
    `SELECT id, title FROM brain_task
      WHERE employee_id = ? AND kind = 'campaign' AND status = 'pending'
      ORDER BY created_at ASC LIMIT 5`
  ).all(EMPLOYEE_ID);

  let drafted = 0;
  for (const t of tasks) {
    const draft = [
      `# Campaign draft: ${t.title}`,
      ``,
      `- Segment    : (stub) audience to target.`,
      `- Message    : (stub) 3 variants for A/B/C testing.`,
      `- Channels   : (stub) email / SEO / social / referral.`,
      `- KPI window : (stub) 14-day window, primary = signup, secondary = MRR.`,
      `- Budget     : requires human approval before spend (outbound money gate).`,
    ].join('\n');
    db.prepare(`UPDATE brain_task SET body_md = ?, status = 'review' WHERE id = ?`).run(draft, t.id);
    drafted += 1;
  }

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, drafted };
}

module.exports = { run, EMPLOYEE_ID };
