# rafcid 取得 + hgc URL 生成 手順

## 1. 楽天アフィリエイト 登録 (10 分)

1. https://affiliate.rakuten.co.jp/ を 開く
2. 楽天会員 ID で ログイン (楽天会員 で なければ 先 に 楽天会員 登録)
3. 「アフィリエイト を 始める」 ボタン → 規約 に 同意
4. サイト / SNS の 登録 (任意 だが 収益 化 に は 必要)
5. 完了 直後 に rafcid (会員 ID) が 発行 される

## 2. rafcid の コピー

管理 画面 の 「レポート」 → 「収益 レポート」 → URL 内 に

```
https://affiliate.rakuten.co.jp/report/?id=wsc_i_is_XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
```

の 形 で 表示 される。 `wsc_i_is_...` の 部分 が rafcid。

これを 秘匿 情報 として 保管 (Keychain / 1Password 等)。 例:

```bash
security add-generic-password -a "$USER" -s "myaffiliate:rakuten:rafcid" -w
# rafcid を 貼り付け (パスワード として 保存)

# 参照
RAFCID=$(security find-generic-password -s "myaffiliate:rakuten:rafcid" -w)
echo "$RAFCID"
```

## 3. アフィリエイト リンク の 作り方 (2 種類)

### A. hgc URL (直リンク)

商品 ページ の URL を 楽天 の hgc gateway に 通す。

```
元 URL:  https://books.rakuten.co.jp/rb/17500000/
hgc URL: https://hb.afl.rakuten.co.jp/hgc/g00qxxxx.xxxxxxxx.g00qxxxx.xxxxxxxx/?pc=https%3A%2F%2Fbooks.rakuten.co.jp%2Frb%2F17500000%2F&link_type=hybrid_url&ut=eyJ...&rafcid=YOUR_RAFCID
```

具体 的 な 生成 は 楽天アフィリエイト の 商品 検索 → 「リンク を 作る」 ボタン で 自動 生成 される。 生成 された URL を そのまま テンプレート の `{{RAKUTEN_URL_N}}` に 貼る。

### B. 検索 結果 リンク

商品 名 だけ 決めて 検索 結果 に 送る 方法。

```
https://search.rakuten.co.jp/search/mall/BOOK_NAME/?scid=af_ich_link_urltxt&sid=213310&rafcid=YOUR_RAFCID
```

`BOOK_NAME` を URL エンコード。 `sid=213310` は 楽天ブックス の ジャンル ID (書籍 検索)。 `rafcid=YOUR_RAFCID` を 自分 の rafcid に 置き換え。

## 4. 中間 リダイレクト 経路 (任意)

自社 ドメイン 経由 で リダイレクト する と クリック 計測 が 楽 に なる。

```
https://your-blog.com/r?to=RAKUTEN_URL_ENCODED
   -> your-blog.com の /r endpoint が 302 リダイレクト
   -> 楽天 の hgc URL
   -> 楽天ブックス 商品 ページ
```

利点:
- クリック 数 を 自社 で 集計 できる (GA4 / 独自 log)
- rafcid の 一括 差し替え が サーバ 側 だけ で 済む
- 楽天 側 の URL 構造 が 変わっても 記事 側 を 書き換え なくて 済む

## 5. 規約 遵守 の チェックリスト

- 記事 冒頭 に 「本 記事 に は 楽天アフィリエイト リンク を 含み ます」 の 開示 文 (景表法 / ステマ 規制 対応)
- 医療 / 金融 / 法律 分野 の 断定 表現 を 避ける (景表法 優良 誤認 の 回避)
- 楽天 の 商標 (「Rakuten」「楽天ブックス」 の 表記) の 濫用 を 避ける
- 楽天 の 内部 リンク や 画像 を そのまま 転載 しない (著作権)
- クッキー ポリシー / プライバシー ポリシー を 記事 の 導線 に 用意

## 6. トラブルシュート

- リンク を クリック しても rafcid が 認識 されない: URL 内 の `rafcid=` パラメータ が 欠落 していない か 確認
- レポート に 反映 されない: 楽天 側 集計 は 24 時間 遅延 が ある
- 承認 されない 案件: 楽天 の 内部 規約 で 除外 され た 商品 の 可能性 (書籍 は 通常 問題 なし)
