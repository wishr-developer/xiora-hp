# Stripe Integration Runbook

Stripe Payment Link + Checkout Session 検証 の Vercel Serverless 実装 パターン。

## 全体像

```
User -> Payment Link (Stripe hosted) -> Success URL
   Success URL = https://YOUR_DOMAIN/api/dl?session_id={CHECKOUT_SESSION_ID}
   -> Vercel Serverless verifies session -> serves digital content
```

## 1. Product / Price / Payment Link を API で 作成

```bash
STRIPE_SECRET_KEY=$(security find-generic-password -s "myorg:stripe:SECRET_KEY" -w)

# Product
PRODUCT_ID=$(curl -sS -u "$STRIPE_SECRET_KEY:" \
  -d name="My Digital Guide" \
  -d 'metadata[product_slug]=my-guide-2026' \
  https://api.stripe.com/v1/products | jq -r '.id')

# Price (JPY 1980, one-time)
PRICE_ID=$(curl -sS -u "$STRIPE_SECRET_KEY:" \
  -d "product=$PRODUCT_ID" \
  -d currency=jpy \
  -d unit_amount=1980 \
  -d 'lookup_key=my_guide_2026_jpy1980' \
  https://api.stripe.com/v1/prices | jq -r '.id')

# Payment Link with redirect to verifier
PL_URL=$(curl -sS -u "$STRIPE_SECRET_KEY:" \
  -d "line_items[0][price]=$PRICE_ID" \
  -d "line_items[0][quantity]=1" \
  -d "after_completion[type]=redirect" \
  -d "after_completion[redirect][url]=https://YOUR_DOMAIN/api/dl?session_id={CHECKOUT_SESSION_ID}" \
  https://api.stripe.com/v1/payment_links | jq -r '.url')

echo "Payment Link: $PL_URL"
```

## 2. Vercel Serverless: `api/dl.js` (verifier)

```javascript
module.exports = async (req, res) => {
  const sessionId = new URL(req.url, 'https://x').searchParams.get('session_id') || '';
  if (!/^cs_[A-Za-z0-9_]{10,}$/.test(sessionId)) return res.writeHead(400).end('bad session');
  const key = process.env.STRIPE_SECRET_KEY;
  const auth = Buffer.from(`${key}:`).toString('base64');
  const r = await fetch(`https://api.stripe.com/v1/checkout/sessions/${sessionId}`, {
    headers: { Authorization: `Basic ${auth}` },
  });
  if (!r.ok) return res.writeHead(502).end('verify failed');
  const s = await r.json();
  if (s.payment_status !== 'paid') return res.writeHead(402).end('not paid');
  // product match: metadata.product_slug OR amount fallback
  // serve the digital content here (HTML / signed download URL)
  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'private, no-store' });
  res.end('<h1>Thank you for your purchase.</h1>');
};
```

## 3. Webhook receiver (optional, for MRR tracking)

```javascript
// api/webhook.js - verifies signature, records revenue_event
const crypto = require('crypto');

module.exports = async (req, res) => {
  const sig = req.headers['stripe-signature'] || '';
  const body = await new Promise(ok => {
    let chunks = []; req.on('data', c => chunks.push(c)); req.on('end', () => ok(Buffer.concat(chunks)));
  });
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  const parts = Object.fromEntries(sig.split(',').map(p => p.split('=')));
  const t = parts.t; const v1 = parts.v1;
  const signed = crypto.createHmac('sha256', secret).update(`${t}.${body.toString()}`).digest('hex');
  if (signed !== v1) return res.writeHead(400).end('bad signature');
  const evt = JSON.parse(body.toString());
  // route by evt.type: checkout.session.completed / invoice.paid / etc.
  res.writeHead(200).end('ok');
};
```

## 4. Test with Stripe test mode

- Use `sk_test_...` key
- Test cards: `4242 4242 4242 4242` any future date, any CVC
- Payment Link with test key issues a test-mode link (identifiable by dashboard toggle)

## 5. Restricted key hygiene

For `dl.js` verifier, create a restricted key with only:
- Checkout Sessions: Read

This means a leaked key cannot mutate customer data, drain funds, or create charges.
