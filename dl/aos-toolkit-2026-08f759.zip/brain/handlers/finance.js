'use strict';
// Finance handler - MRR / churn / dunning summary + billing gate escalation.
// Any outbound money flow requires an explicit human decision.

const EMPLOYEE_ID = 'finance';

async function run(db, ctx = {}) {
  // Aggregate revenue events for the past 24h.
  const mrr = db.prepare(
    `SELECT COALESCE(SUM(amount_jpy), 0) AS mrr_delta_24h,
            COUNT(*)                     AS events_24h
       FROM revenue_event
      WHERE created_at > datetime('now','-1 day')`
  ).get() || { mrr_delta_24h: 0, events_24h: 0 };

  const outstanding = db.prepare(
    `SELECT COUNT(*) AS n FROM invoice WHERE status = 'open'`
  ).get() || { n: 0 };

  const body = [
    `# Finance daily ${new Date().toISOString().slice(0,10)}`,
    ``,
    `- MRR delta 24h : JPY ${mrr.mrr_delta_24h}`,
    `- Events 24h    : ${mrr.events_24h}`,
    `- Open invoices : ${outstanding.n}`,
    ``,
    `## Billing gate reminder`,
    `Outbound money flow (refunds, payouts, ad spend increase) always requires an explicit human decision. Finance handler drafts, human decides.`,
  ].join('\n');

  db.prepare(
    `INSERT INTO brain_task (employee_id, kind, title, body_md, status, created_at)
     VALUES (?, 'report', ?, ?, 'done', datetime('now'))`
  ).run(EMPLOYEE_ID, `Finance daily ${new Date().toISOString().slice(0,10)}`, body);

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = 'ok', run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, mrr };
}

module.exports = { run, EMPLOYEE_ID };
