#!/usr/bin/env bash
# Autonomous Company OS - 24/7 Supervisor
# ============================================================
# Keeps `node brain/runtime.js` alive with auto-restart on abnormal exit.
# Uses PID files for double-start prevention (both supervisor + runtime).
#
# Usage:
#   brain/scripts/supervisor.sh start          # start in background
#   brain/scripts/supervisor.sh stop           # stop supervisor + runtime
#   brain/scripts/supervisor.sh status         # show state
#   brain/scripts/supervisor.sh restart        # stop + start
#
# Auto-start on reboot via cron:
#   crontab -e
#   @reboot /path/to/your/repo/brain/scripts/supervisor.sh start

set -Eeuo pipefail
set -o noclobber

# ---- config (edit these to match your layout) ----
BRAIN_DIR="${BRAIN_DIR:-$(cd "$(dirname "$0")/.." && pwd)}"
SUPERVISOR_PID_FILE="${BRAIN_DIR}/supervisor.pid"
RUNTIME_PID_FILE="${BRAIN_DIR}/runtime.pid"
LOG_FILE="${BRAIN_DIR}/logs/runtime.log"
ERR_FILE="${BRAIN_DIR}/logs/runtime.err.log"
SUPERVISOR_LOG="${BRAIN_DIR}/logs/supervisor.log"
NODE="${NODE:-/usr/local/bin/node}"
RUNTIME_SCRIPT="${BRAIN_DIR}/runtime.js"
RESTART_MIN_INTERVAL_SEC=30

mkdir -p "${BRAIN_DIR}/logs"

alive() { [ -n "${1:-}" ] && kill -0 "$1" 2>/dev/null; }
now()   { date -u +%Y-%m-%dT%H:%M:%SZ; }
slog()  { echo "[$(now)] $*" >> "$SUPERVISOR_LOG"; }

start() {
  if [ -f "$SUPERVISOR_PID_FILE" ]; then
    sup_pid=$(cat "$SUPERVISOR_PID_FILE" 2>/dev/null || echo "")
    if alive "$sup_pid"; then
      echo "supervisor already running (pid $sup_pid)"; exit 78
    fi
    rm -f "$SUPERVISOR_PID_FILE"
  fi
  ( _loop ) >> "$SUPERVISOR_LOG" 2>&1 &
  disown
  local sup_pid=$!
  echo "$sup_pid" > "$SUPERVISOR_PID_FILE"
  echo "supervisor started (pid $sup_pid). log: $SUPERVISOR_LOG"
}

_loop() {
  slog "supervisor pid=$$ starting"
  local last_start=0
  local runs=0
  while :; do
    local now_epoch=$(date +%s)
    local since_last=$((now_epoch - last_start))
    if [ "$since_last" -lt "$RESTART_MIN_INTERVAL_SEC" ]; then
      local wait=$((RESTART_MIN_INTERVAL_SEC - since_last))
      slog "throttle: sleeping ${wait}s"; sleep "$wait"
    fi
    last_start=$(date +%s)
    runs=$((runs + 1))
    slog "spawn #${runs}: exec node runtime.js"
    NODE_PATH="${BRAIN_DIR}/node_modules" \
    BRAIN_HEALTH_PORT="${BRAIN_HEALTH_PORT:-8877}" \
    "$NODE" "$RUNTIME_SCRIPT" >> "$LOG_FILE" 2>> "$ERR_FILE" &
    local child=$!
    echo "$child" > "$RUNTIME_PID_FILE"
    slog "runtime pid=$child spawned"
    set +e
    wait "$child"
    local rc=$?
    set -e
    slog "runtime pid=$child exited rc=$rc"
    if [ "$rc" -eq 0 ]; then
      slog "clean exit rc=0, supervisor stopping"
      break
    fi
  done
  slog "supervisor loop end"
  rm -f "$SUPERVISOR_PID_FILE" "$RUNTIME_PID_FILE"
}

stop() {
  local sup_pid=""
  local run_pid=""
  [ -f "$SUPERVISOR_PID_FILE" ] && sup_pid=$(cat "$SUPERVISOR_PID_FILE" 2>/dev/null || true)
  [ -f "$RUNTIME_PID_FILE" ] && run_pid=$(cat "$RUNTIME_PID_FILE" 2>/dev/null || true)

  if alive "$sup_pid"; then
    slog "stop: killing supervisor pid=$sup_pid"
    kill -TERM "$sup_pid" 2>/dev/null || true
  fi
  if alive "$run_pid"; then
    slog "stop: killing runtime pid=$run_pid"
    kill -TERM "$run_pid" 2>/dev/null || true
    sleep 2
    alive "$run_pid" && kill -KILL "$run_pid" 2>/dev/null || true
  fi
  rm -f "$SUPERVISOR_PID_FILE" "$RUNTIME_PID_FILE"
  echo "supervisor stopped"
}

status() {
  local sup_pid=""
  local run_pid=""
  [ -f "$SUPERVISOR_PID_FILE" ] && sup_pid=$(cat "$SUPERVISOR_PID_FILE" 2>/dev/null || true)
  [ -f "$RUNTIME_PID_FILE" ] && run_pid=$(cat "$RUNTIME_PID_FILE" 2>/dev/null || true)
  local sup_state="stopped"
  local run_state="stopped"
  alive "$sup_pid" && sup_state="running (pid $sup_pid)"
  alive "$run_pid" && run_state="running (pid $run_pid)"
  echo "supervisor: $sup_state"
  echo "runtime:    $run_state"
  echo "log:        $LOG_FILE"
  echo "err:        $ERR_FILE"
}

restart() { stop || true; sleep 1; start; }

case "${1:-status}" in
  start)   start ;;
  stop)    stop ;;
  status)  status ;;
  restart) restart ;;
  *) echo "Usage: $0 {start|stop|status|restart}" ; exit 64 ;;
esac
