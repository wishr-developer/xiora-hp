'use strict';
// QA handler - test runner + regression sweep + gating decisions.
// Uses execFile (no shell) to invoke the test command safely.

const { execFileSync } = require('child_process');

const EMPLOYEE_ID = 'qa';

async function run(db, ctx = {}) {
  // Test command must be split into program + args tokens (no shell string).
  const testProgram = (ctx.testProgram || 'echo');
  const testArgs = (ctx.testArgs || ['no test command configured']);
  let ok = true;
  let output = '';
  try {
    output = execFileSync(testProgram, testArgs, { encoding: 'utf8', timeout: 5 * 60 * 1000 }).slice(0, 8000);
  } catch (e) {
    ok = false;
    output = String(e.stdout || e.message || '').slice(0, 8000);
  }

  db.prepare(
    `INSERT INTO brain_task (employee_id, kind, title, body_md, status, created_at)
     VALUES (?, 'report', ?, ?, ?, datetime('now'))`
  ).run(
    EMPLOYEE_ID,
    `QA sweep ${new Date().toISOString().slice(0,16)}`,
    '```\n' + output + '\n```',
    ok ? 'done' : 'failed'
  );

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), ?, 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'), last_status = ?, run_count = run_count + 1`
  ).run(EMPLOYEE_ID, ok ? 'ok' : 'fail', ok ? 'ok' : 'fail');

  if (!ok) {
    db.prepare(
      `INSERT INTO detection (employee_id, severity, category, subject, status, detected_at)
       VALUES (?, 'high', 'qa', 'QA sweep failed - see latest QA report', 'open', datetime('now'))`
    ).run(EMPLOYEE_ID);
  }

  return { ok, employee: EMPLOYEE_ID };
}

module.exports = { run, EMPLOYEE_ID };
