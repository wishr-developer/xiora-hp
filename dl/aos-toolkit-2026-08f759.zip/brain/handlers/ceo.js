'use strict';
// CEO handler - daily company-wide summary + prioritization proposal.
//
// Xiora Autonomous Company OS reference implementation. Reads from a shared
// SQLite state.db, produces a report task, and (optionally) advances the
// business cycle orchestrator.
//
// Expected tables (create via your own schema.sql):
//   detection(id, employee_id, severity, category, subject, status, detected_at)
//   proposal(id, employee_id, status, proposed_at)
//   brain_task(id, employee_id, kind, title, body_md, status, created_at)
//   employee_state(employee_id, last_run_at, last_status, run_count)
//   halt_log(id, triggered_at, reason)

const EMPLOYEE_ID = 'ceo';

async function run(db, ctx = {}) {
  // Aggregate: last 24h detection/proposal/task counters.
  const stats = db.prepare(
    `SELECT
       (SELECT COUNT(*) FROM detection  WHERE detected_at > datetime('now','-1 day')) AS det_24h,
       (SELECT COUNT(*) FROM detection  WHERE detected_at > datetime('now','-1 day') AND severity IN ('high','critical')) AS det_high_24h,
       (SELECT COUNT(*) FROM proposal   WHERE proposed_at > datetime('now','-1 day')) AS prop_24h,
       (SELECT COUNT(*) FROM proposal   WHERE status='pending')                       AS prop_pending,
       (SELECT COUNT(*) FROM brain_task WHERE created_at > datetime('now','-1 day')) AS task_24h,
       (SELECT COUNT(*) FROM halt_log   WHERE triggered_at > datetime('now','-1 day')) AS halts_24h`
  ).get();

  const employees = db.prepare(
    `SELECT employee_id, last_run_at, last_status, run_count FROM employee_state ORDER BY employee_id`
  ).all();

  const topPriority = db.prepare(
    `SELECT id, employee_id, severity, category, subject
       FROM detection
      WHERE status='open' AND severity IN ('high','critical')
      ORDER BY CASE severity WHEN 'critical' THEN 0 ELSE 1 END, detected_at DESC
      LIMIT 5`
  ).all();

  const reportBody = [
    `# CEO Daily Company Report (${new Date().toISOString().slice(0,10)})`,
    ``,
    `## 24h counters`,
    `- detections: ${stats.det_24h} (high/critical: ${stats.det_high_24h})`,
    `- proposals:  ${stats.prop_24h} (pending: ${stats.prop_pending})`,
    `- tasks:      ${stats.task_24h}`,
    `- halts:      ${stats.halts_24h}`,
    ``,
    `## Employee heartbeat`,
    employees.length
      ? employees.map(e => `- ${e.employee_id}: last=${e.last_run_at} status=${e.last_status} runs=${e.run_count}`).join('\n')
      : '_(no employees have run yet)_',
    ``,
    `## Top priority (open high/critical detections)`,
    topPriority.length
      ? topPriority.map(t => `1. [${t.severity.toUpperCase()}] ${t.employee_id} -> ${t.subject}`).join('\n')
      : '_(no open high/critical)_',
    ``,
    `## CEO recommendation`,
    topPriority.length
      ? `Focus AI workforce on the ${topPriority.length} top-priority items. Manager should reassign task ownership if any is orphan >6h.`
      : `All monitored services are within thresholds. Continue standing agenda.`,
  ].join('\n');

  db.prepare(
    `INSERT INTO brain_task (employee_id, kind, title, body_md, status, created_at)
     VALUES (?, ?, ?, ?, 'done', datetime('now'))`
  ).run(EMPLOYEE_ID, 'report', `CEO Daily Report ${new Date().toISOString().slice(0,10)}`, reportBody);

  db.prepare(
    `INSERT INTO employee_state (employee_id, last_run_at, last_status, run_count)
     VALUES (?, datetime('now'), 'ok', 1)
     ON CONFLICT(employee_id) DO UPDATE SET
       last_run_at = datetime('now'),
       last_status = 'ok',
       run_count = run_count + 1`
  ).run(EMPLOYEE_ID);

  return { ok: true, employee: EMPLOYEE_ID, stats, priority_count: topPriority.length };
}

module.exports = { run, EMPLOYEE_ID };
